/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct node
{
    int info;
    struct node *llink,*rlink;
};
typedef struct node nd;
void postorder(nd *);
nd* insert(nd *,int );
void inorder(nd *);
void preorder(nd *);
void search(nd *,int );
int main()
{
    nd *root=0;
    int key,ch;
    for(;;)
    {
        printf("1:insert\n2:search\n3:preorder\n4:inorder\n5:postorder\n6:exit\n");
        printf("Enter the choice\n");
        scanf("%d",&ch);
        switch(ch)
        {
            case 1 : printf("enter the no of elements\n");
                     int n;
                     scanf("%d",&n);
                     printf("enter the elements\n");
                     for(int i=0;i<n;i++)
                     {   
                         scanf("%d",&key);
                         root=insert(root,key);
                     }
                     break;
            case 2 : printf("enter the element to be searched\n");
                     scanf("%d",&key);
                     search(root,key);
                     break;
            case 3 : preorder(root);  break;
            case 4 : inorder(root); break;
            case 5 : postorder(root); break;
            default : exit(0);
        }
    }
}

nd* insert(nd *root,int key)
{
    nd *t;
    t=(nd *)malloc(sizeof(nd));
    t->info=key;
    t->llink=t->rlink=0;
    nd *prev=0,*cur=root;
    if(!cur)
       return t;
    while(cur)
    {
        if(t->info==cur->info)
        {
            printf("Redundancy\n");
            free(t);
            return root;
        }
        prev=cur;
        if(t->info<cur->info)
           cur=cur->llink;
        else
            cur=cur->rlink;
    }
    if(t->info<prev->info)
        prev->llink=t;
    else 
        prev->rlink=t;
        return root;
}

void search(nd *root,int key)
{
    if(!root)
    {
        printf("Bst is empty\n");
        return;
    }
    while(root)
    {     if(key==root->info)
        {
            printf("Search successful\n");
            return;
        }
         if(key<root->info)
           root=root->llink;
        else
            root=root->rlink;
    }
    printf("Unsuccessful search\n");
}

void preorder(nd *root)
{
    if(root)
    {
        printf("%d ",root->info);
        preorder(root->llink);
        preorder(root->rlink);
    }
}
void inorder(nd *root)
{
    if(root)
    {
        inorder(root->llink);
        printf("%d ",root->info);
        inorder(root->rlink);
    }
}
void postorder(nd *root)
{
    if(root)
    {
        postorder(root->llink);
        postorder(root->rlink);
        printf("%d ",root->info);
    }
}